'use strict';

export default {disableCSSInjection: false};
